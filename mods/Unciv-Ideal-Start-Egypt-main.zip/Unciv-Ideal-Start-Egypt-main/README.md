# Unciv-Ideal-Start-Egypt
# Ideal Start Egypt Mod
Cheat start for Egypt civilization
